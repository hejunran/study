# --------------------------------------------------------
# dota_evaluation_task1
# Licensed under The MIT License [see LICENSE for details]
# Written by Jian Ding, based on code from Bharath Hariharan
# Modified version
# --------------------------------------------------------

"""
    To use the code, users should to config detpath, annopath and imagesetfile
    detpath is the path for 15 result files, for the format, you can refer to "http://captain.whu.edu.cn/DOTAweb/tasks.html"
    search for PATH_TO_BE_CONFIGURED to config the paths
    Note, the evaluation is on the large scale images
"""
import xml.etree.ElementTree as ET
import os
import numpy as np
from rotate.box_utils.CSL import iou_rotate


def parse_gt(filename):
    objects = []
    target = ET.parse(filename).getroot()
    for obj in target.iter('HRSC_Object'):
        object_struct = {}
        difficult = int(obj.find('difficult').text)
        box_xmin = int(obj.find('box_xmin').text)  # bbox
        box_ymin = int(obj.find('box_ymin').text)
        box_xmax = int(obj.find('box_xmax').text)
        box_ymax = int(obj.find('box_ymax').text)
        mbox_cx = float(obj.find('mbox_cx').text)  # rbox
        mbox_cy = float(obj.find('mbox_cy').text)
        mbox_w = float(obj.find('mbox_w').text)
        mbox_h = float(obj.find('mbox_h').text)
        mbox_ang = float(obj.find('mbox_ang').text) * 180 / np.pi

        object_struct['name'] = 'ship'
        object_struct['difficult'] = difficult
        object_struct['bbox'] = [mbox_cx,
                                 mbox_cy,
                                 mbox_w,
                                 mbox_w,
                                 mbox_h,
                                 mbox_ang]
        objects.append(object_struct)
    return objects


def voc_ap(rec, prec, use_07_metric=False):
    """ ap = voc_ap(rec, prec, [use_07_metric])
    Compute VOC AP given precision and recall.
    If use_07_metric is true, uses the
    VOC 07 11 point method (default:False).
    """
    if use_07_metric:
        # 11 point metric
        ap = 0.
        for t in np.arange(0., 1.1, 0.1):
            if np.sum(rec >= t) == 0:
                p = 0
            else:
                p = np.max(prec[rec >= t])
            ap = ap + p / 11.
    else:
        # correct AP calculation
        # first append sentinel values at the end
        mrec = np.concatenate(([0.], rec, [1.]))
        mpre = np.concatenate(([0.], prec, [0.]))

        # compute the precision envelope
        for i in range(mpre.size - 1, 0, -1):
            mpre[i - 1] = np.maximum(mpre[i - 1], mpre[i])

        # to calculate area under PR curve, look for points
        # where X axis (recall) changes val
        i = np.where(mrec[1:] != mrec[:-1])[0]

        # and sum (\Delta recall) * prec
        ap = np.sum((mrec[i + 1] - mrec[i]) * mpre[i + 1])
    return ap


def voc_eval(detpath,
             annopath,
             imagesetfile,
             classname,
             ovthresh=0.5,
             use_07_metric=False):
    with open(imagesetfile, 'r') as f:
        lines = f.readlines()
    imagenames = [x.strip() for x in lines]
    recs = {}
    for i, imagename in enumerate(imagenames):
        print(annopath.format(imagename))
        recs[imagename] = parse_gt(os.path.join(annopath, imagename, '.xml'))
    # extract gt objects for this class
    class_recs = {}
    npos = 0
    for imagename in imagenames:
        R = [obj for obj in recs[imagename] if obj['name'] == classname]
        bbox = np.array([x['bbox'] for x in R])
        difficult = np.array([x['difficult'] for x in R]).astype(np.bool)
        det = [False] * len(R)
        npos = npos + sum(~difficult)
        class_recs[imagename] = {'bbox': bbox,
                                 'difficult': difficult,
                                 'det': det}

    # read dets from Task1* files
    detfile = detpath.format(classname)
    with open(detfile, 'r') as f:
        lines = f.readlines()

    splitlines = [x.strip().split(' ') for x in lines]
    image_ids = [x[0] for x in splitlines]
    confidence = np.array([float(x[1]) for x in splitlines])

    # print('check confidence: ', confidence)

    BB = np.array([[float(z) for z in x[2:]] for x in splitlines])

    if len(confidence) > 1:
        # sort by confidence
        sorted_ind = np.argsort(-confidence)
        sorted_scores = np.sort(-confidence)

        # print('check sorted_scores: ', sorted_scores)
        # print('check sorted_ind: ', sorted_ind)

        ## note the usage only in numpy not for list
        BB = BB[sorted_ind, :]
        image_ids = [image_ids[x] for x in sorted_ind]
    # print('check imge_ids: ', image_ids)
    # print('imge_ids len:', len(image_ids))
    # go down dets and mark TPs and FPs
    nd = len(image_ids)
    tp = np.zeros(nd)
    fp = np.zeros(nd)
    for d in range(nd):
        R = class_recs[image_ids[d]]
        bb = BB[d, :].astype(float)
        ovmax = -np.inf
        BBGT = R['bbox'].astype(float)

        ## compute det bb with each BBGT

        if BBGT.size > 0:
            # compute overlaps
            # intersection
            # ixmin = np.maximum(BBGT[:, 0], bb[0])
            # iymin = np.maximum(BBGT[:, 1], bb[1])
            # ixmax = np.minimum(BBGT[:, 2], bb[2])
            # iymax = np.minimum(BBGT[:, 3], bb[3])
            # iw = np.maximum(ixmax - ixmin + 1., 0.)
            # ih = np.maximum(iymax - iymin + 1., 0.)
            # inters = iw * ih
            #
            # # union
            # uni = ((bb[2] - bb[0] + 1.) * (bb[3] - bb[1] + 1.) +
            #        (BBGT[:, 2] - BBGT[:, 0] + 1.) *
            #        (BBGT[:, 3] - BBGT[:, 1] + 1.) - inters)
            #
            # overlaps = inters / uni
            overlaps = []
            for i in range(len(BBGT)):
                overlap = iou_rotate.iou_rotate_calculate1(np.array([bb]),
                                                           BBGT[i])[0]
                overlaps.append(overlap)
            ovmax = np.max(overlaps)
            jmax = np.argmax(overlaps)

        if ovmax > ovthresh:
            if not R['difficult'][jmax]:
                if not R['det'][jmax]:
                    tp[d] = 1.
                    R['det'][jmax] = 1
                else:
                    fp[d] = 1.
        else:
            fp[d] = 1.

    # compute precision recall

    # print('check fp:', fp)
    # print('check tp', tp)

    # print('npos num:', npos)
    fp = np.cumsum(fp)
    tp = np.cumsum(tp)

    rec = tp / float(npos)
    # avoid divide by zero in case the first detection matches a difficult
    # ground truth
    prec = tp / np.maximum(tp + fp, np.finfo(np.float64).eps)
    ap = voc_ap(rec, prec, use_07_metric)

    return rec, prec, ap


def main():
    detpath = r'../test/result_offshore.txt'
    annopath = r'HRSC2016/label/val'  # change the directory to the path of val/labelTxt, if you want to do evaluation on the valset
    imagesetfile = r'../HRSC2016/test.txt'
    classnames = ['ship']
    classaps = []
    map = 0
    for classname in classnames:
        print('classname:', classname)
        rec, prec, ap = voc_eval(detpath,
                                 annopath,
                                 imagesetfile,
                                 classname,
                                 ovthresh=0.5,
                                 use_07_metric=True)
        map = map + ap
        # print('rec: ', rec, 'prec: ', prec, 'ap: ', ap)
        print('ap: ', ap)
        classaps.append(ap)

        # umcomment to show p-r curve of each category
        # plt.figure(figsize=(8,4))
        # plt.xlabel('recall')
        # plt.ylabel('precision')
        # plt.plot(rec, prec)
    # plt.show()
    map = map / len(classnames)
    print('map:', map)
    classaps = 100 * np.array(classaps)
    print('classaps: ', classaps)


if __name__ == '__main__':
    main()
