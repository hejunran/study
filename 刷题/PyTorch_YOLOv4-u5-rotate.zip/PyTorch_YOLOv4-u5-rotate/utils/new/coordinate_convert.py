import numpy as np
import cv2
import torch


def box_center_to_corners_tensor(b, with_label=False):
    """
    Converts a set of oriented bounding boxes from
    centered representation (x_c, y_c, w, h, theta) to corner representation (x0, y0, ..., x3, y3).

    Arguments:
        b (Tensor[N, 6]): boxes to be converted. They are
            expected to be in (x_c, y_c, w, h, angle, [label]) format.
            :param b: boxes
            :param with_label: Whether boxes have labels or not

    Returns:
        c (Tensor[N, 8]): converted boxes in (x0, y0, ..., x3, y3) format, where
            the corners are sorted counterclockwise.

    """
    if with_label:
        x_c, y_c, w, h, angle, label = b.unbind(-1)  # [N,]
    else:
        x_c, y_c, w, h, angle = b.unbind(-1)  # [N,]

    theta = angle * np.pi / 180

    c = torch.cos(theta)
    s = torch.sin(theta)

    center = torch.stack([x_c, y_c], dim=-1).repeat(1, 4)  # [N, 8]

    dx = 0.5 * w
    dy = 0.5 * h
    c = c + 1e-5
    s = s + 1e-5
    cos = c / ((c ** 2 + s ** 2).sqrt() + 1e-10)
    sin = s / ((c ** 2 + s ** 2).sqrt() + 1e-10)

    dxcos = dx * cos
    dxsin = dx * sin
    dycos = dy * cos
    dysin = dy * sin

    dxy = [- dxcos - dysin, - dxsin + dycos,
           - dxcos + dysin, - dxsin - dycos,
           dxcos + dysin, dxsin - dycos,
           dxcos - dysin, dxsin + dycos]

    # corners = center + torch.stack(dxy, dim=-1)  # [N, 8]
    if with_label:
        corners = torch.cat([center + torch.stack(dxy, dim=-1), torch.unsqueeze(label, 1)], 1)
    else:
        corners = center + torch.stack(dxy, dim=-1)

    return corners  # [N, 8[+1]]


def box_corners_to_center_tensor(corners, with_label=False):
    """
    Arguments:
        corners (Tensor[N, 8]): boxes to be converted. They are
            expected to be in (x0, y0, ..., x3, y3, [label]) format, where the corners are sorted counterclockwise.
            :param corners: corners
            :param with_label: Whether corners have labels or not

    Returns:
        b (Tensor[N, 6]): converted boxes in centered
            (x_c, y_c, w, h, theta, [label]) format.

    """
    if with_label:
        x0, y0, x1, y1, x2, y2, x3, y3, label = corners.unbind(-1)
    else:
        x0, y0, x1, y1, x2, y2, x3, y3 = corners.unbind(-1)

    x_c = (x0 + x2) / 2
    y_c = (y0 + y2) / 2

    hcos, hsin, wsin, wcos = (y0 - y1,
                              x0 - x1,
                              y0 - y3,
                              x3 - x0)
    theta = -(torch.atan2(wsin, wcos)) * 180 / np.pi

    if with_label:
        b = [x_c, y_c,
             (wsin ** 2 + wcos ** 2).sqrt(),
             (hsin ** 2 + hcos ** 2).sqrt(),
             theta, label]
    else:
        b = [x_c, y_c,
             (wsin ** 2 + wcos ** 2).sqrt(),
             (hsin ** 2 + hcos ** 2).sqrt(),
             theta]

    return torch.stack(b, dim=-1)


def coordinate_present_convert(coords):
    """
    :param coords: shape [-1, 5]
    :param: convert  [-180, 0) to [-90, 0)
    :return: shape [-1, 5]
    """
    coords[:, 4] += 90

    theta = coords[:, 4]
    remain_mask = torch.ge(theta, -90) & torch.gt(-theta, 0)
    convert_mask = ~remain_mask

    remain_coords = coords * remain_mask.view(-1, 1).float()

    coords[:, [2, 3]] = coords[:, [3, 2]]
    coords[:, 4] -= 90

    convert_coords = coords * convert_mask.view(-1, 1).float()

    coords_new = remain_coords + convert_coords

    return coords_new


def coordinate_present_convert_pre(coords, mode=1):
    """
    :param coords: shape [-1, 5]
    :param mode: -1 convert coords range to [-180, 0), 1 convert coords range to [-90, 0)
    :return: shape [-1, 5]
    """
    # angle range from [-90, 0) to [-180, 0)
    new_coords = coords.copy()
    if mode == -1:
        mask = np.where(new_coords[:, 2] < new_coords[:, 3])
        if len(mask[0]):
            for idx in mask[0]:
                new_coords[idx, [2, 3]] = new_coords[idx, [3, 2]]
                new_coords[idx, 4] = new_coords[idx, 4] - 90
    # angle range from [-180, 0) to [-90, 0)
    elif mode == 1:
        mask = new_coords[:, 2] < -90
        if len(mask[0]):
            for idx in mask[0]:
                new_coords[idx, 2], new_coords[idx, 3] = new_coords[idx, 3], new_coords[idx, 2]
                new_coords[idx, 4] = new_coords[idx, 4] + 90
    return new_coords


def box_corners_to_center(corners, with_label=True):
    """
    (x0, y0, ..., x3, y3, [label]) to (x_c, y_c, w, h, theta, [label]).
    """
    centers = []
    for b in corners:
        if with_label:
            label, x0, y0, x1, y1, x2, y2, x3, y3 = b[:]
        else:
            x0, y0, x1, y1, x2, y2, x3, y3 = b[:]

        x_c = (x0 + x2) / 2
        y_c = (y0 + y2) / 2

        hcos, hsin, wsin, wcos = (y0 - y1,
                                  x0 - x1,
                                  y0 - y3,
                                  x3 - x0)
        theta = -(np.arctan2(wsin, wcos)) * 180 / np.pi

        if with_label:
            center = [label, x_c, y_c,
                      np.sqrt((wsin ** 2 + wcos ** 2)),
                      np.sqrt((hsin ** 2 + hcos ** 2)),
                      theta]
        else:
            center = [x_c, y_c,
                      np.sqrt((wsin ** 2 + wcos ** 2)),
                      np.sqrt((hsin ** 2 + hcos ** 2)),
                      theta]
        centers.append(center)

    return np.array(centers)


def box_center_to_corners(centers, with_label=True):
    """
    (x_c, y_c, w, h, theta, [label]) to corner representation (x0, y0, ..., x3, y3, [label]).
    """
    corners = []
    for b in centers:
        if with_label:
            label = b[0:1]
            x_c, y_c, w, h, angle = b[1:]  # [N,]
        else:
            x_c, y_c, w, h, angle = b[:]  # [N,]

        theta = angle * np.pi / 180

        c = np.cos(theta)
        s = np.sin(theta)

        center = np.stack([x_c, y_c], axis=0).repeat(4, axis=0)  # [N, 8]

        dx = 0.5 * w
        dy = 0.5 * h
        c = c + 1e-5
        s = s + 1e-5
        cos = c / (np.sqrt(c ** 2 + s ** 2) + 1e-10)
        sin = s / (np.sqrt(c ** 2 + s ** 2) + 1e-10)

        dxcos = dx * cos
        dxsin = dx * sin
        dycos = dy * cos
        dysin = dy * sin

        dxy = [- dxcos - dysin, - dxsin + dycos,
               - dxcos + dysin, - dxsin - dycos,
               dxcos + dysin, dxsin - dycos,
               dxcos - dysin, dxsin + dycos]

        # corners = center + torch.stack(dxy, dim=-1)  # [N, 8]
        if with_label:
            corner = np.concatenate([label, center + dxy], axis=0)
        else:
            corner = center + dxy

        corners.append(corner)
    return np.array(corners)  # [N, 8[+1]]


def forward_convert(coordinate, with_label=True):
    """
    :param coordinate: format [x_c, y_c, w, h, theta]
    :return: format [x1, y1, x2, y2, x3, y3, x4, y4]
    """

    boxes = []
    if with_label:
        for rect in coordinate:
            box = cv2.boxPoints(((rect[1], rect[2]), (rect[3], rect[4]), rect[5]))
            box = np.reshape(box, [-1, ])
            boxes.append([rect[0], box[0], box[1], box[2], box[3], box[4], box[5], box[6], box[7]])
    else:
        for rect in coordinate:
            box = cv2.boxPoints(((rect[0], rect[1]), (rect[2], rect[3]), rect[4]))
            box = np.reshape(box, [-1, ])
            boxes.append([box[0], box[1], box[2], box[3], box[4], box[5], box[6], box[7]])

    return np.array(boxes, dtype=np.float32)


def backward_convert(coordinate, with_label=True):
    """
    :param coordinate: format [x1, y1, x2, y2, x3, y3, x4, y4, (label)]
    :param with_label: default True
    :return: format [x_c, y_c, w, h, theta, (label)]
    """

    boxes = []
    if with_label:
        for rect in coordinate:
            box = np.int0(rect[1:])
            box = box.reshape([4, 2])
            rect1 = cv2.minAreaRect(box)

            x, y, w, h, theta = rect1[0][0], rect1[0][1], rect1[1][0], rect1[1][1], rect1[2]
            boxes.append([rect[0], x, y, w, h, theta])

    else:
        for rect in coordinate:
            box = np.int0(rect)
            box = box.reshape([4, 2])
            rect1 = cv2.minAreaRect(box)

            x, y, w, h, theta = rect1[0][0], rect1[0][1], rect1[1][0], rect1[1][1], rect1[2]
            boxes.append([x, y, w, h, theta])

    return np.array(boxes, dtype=np.float32)
