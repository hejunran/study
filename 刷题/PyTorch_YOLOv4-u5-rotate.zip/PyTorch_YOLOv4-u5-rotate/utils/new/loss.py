#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2021/3/27 11:29
# @Author : zheng_zy
# @File : loss.py
# @Describe:
import torch


def smooth_l1_loss(inputs,
                   targets,
                   beta=1. / 9,
                   size_average=True,
                   weight=None):
    """
    https://github.com/facebookresearch/maskrcnn-benchmark
    """
    diff = torch.abs(inputs - targets)
    if weight is None:
        loss = torch.where(
            diff < beta,
            0.5 * diff ** 2 / beta,
            diff - 0.5 * beta
        )
    else:
        loss = torch.where(
            diff < beta,
            0.5 * diff ** 2 / beta,
            diff - 0.5 * beta
        ) * weight.max(1)[0].unsqueeze(1).repeat(1, 5)
    torch.sum(loss, dim=0)
    return loss
    # if size_average:
    #     return loss.mean()
    # return loss.sum()
