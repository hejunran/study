from torch.autograd import Function
import torch
import min_circle


class CircleFunction(Function):
    @staticmethod
    def forward(ctx, points):
        """
        It must accept a context ctx as the first argument, followed by any
        number of arguments (tensors or other types).
        The context can be used to store tensors that can be then retrieved
        during the backward pass."""
        cr = min_circle.forward(points)
        ctx.mark_non_differentiable(cr)
        return cr

    @staticmethod
    def backward(ctx, gradOutput):
        return ()


cir = CircleFunction.apply

def cir_tensor(points):
    a1 = points[:, 1, 0] - points[:, 0, 0]
    b1 = points[:, 1, 1] - points[:, 0, 1]
    c1 = (a1 * a1 + b1 * b1) / 2
    a2 = points[:, 2, 0] - points[:, 0, 0]
    b2 = points[:, 2, 1] - points[:, 0, 1]
    c2 = (a2 * a2 + b2 * b2) / 2
    d = a1 * b2 - a2 * b1

    cir_centers_x = torch.where(torch.abs(d) < 1e-6,
                                (points[:, 0, 0] + points[:, 1, 0]) / 2,
                                points[:, 0, 0] + (c1 * b2 - c2 * b1) / d)

    cir_centers_y = torch.where(torch.abs(d) < 1e-6,
                                (points[:, 0, 1] + points[:, 1, 1]) / 2,
                                points[:, 0, 1] + (a1 * c2 - a2 * c1) / d)

    return torch.stack([cir_centers_x, cir_centers_y], dim=1)


def dist_tensor(p1, p2):
    print(p1, p2)
    return torch.sqrt(torch.pow(p1[:, 0] - p2[:, 0], 2) + torch.pow(p1[:, 1] - p2[:, 1], 2))


if __name__ == "__main__":
    corners = torch.tensor([[[0.40384, 4.53945],
                      [-3.25732, 1.11031],
                      [1.00631, -3.44180],
                      [4.66747, -0.01265],
                      [-1.71876, 0.99998],
                      [-1.85221, -0.21785],
                      [2.71876, -0.71873],
                      [2.85221, 0.49910]],

                     [[2.79354, 3.54836],
                      [-1.36848, 4.06051],
                      [-2.18124, -2.54445],
                      [1.98079, -3.05660],
                      [-2.03126, 1.37497],
                      [-2.26029, 0.30796],
                      [3.70847, -0.97322],
                      [3.93750, 0.09379]],

                     [[-2.86313, 2.52345],
                      [-3.35706, 1.02617],
                      [3.82699, -1.34376],
                      [4.32093, 0.15352],
                      [3.01204, 3.26948],
                      [-2.26917, 0.01941],
                      [-1.46872, -1.28128],
                      [3.81249, 1.96879]],

                     [[3.48908, 4.21316],
                      [-3.70296, 0.60761],
                      [-1.93635, -2.91628],
                      [5.25569, 0.68927],
                      [3.01204, 3.26948],
                      [-2.26917, 0.01941],
                      [-1.46872, -1.28128],
                      [3.81249, 1.96879]],

                     [[2.25934, 3.83777],
                      [-2.91731, 0.32346],
                      [-0.87067, -2.69129],
                      [4.30598, 0.82302],
                      [0.47442, 3.73560],
                      [-1.46872, -2.00002],
                      [0.05683, -2.51685],
                      [1.99997, 3.21877]],

                     [[1.03816, 4.00420],
                      [-2.35968, 2.85539],
                      [-0.33894, -3.12138],
                      [3.05890, -1.97257],
                      [0.96952, 3.29235],
                      [0.62502, -1.53126],
                      [1.65548, -1.60485],
                      [1.99997, 3.21876]],

                     [[-0.27946, 5.11545],
                      [-3.90977, 0.95290],
                      [1.74039, -3.97482],
                      [5.37071, 0.18772],
                      [-2.71876, 0.99998],
                      [-2.85221, -0.21785],
                      [1.71876, -0.71873],
                      [1.85221, 0.49910]],

                     [[0.56689, 2.84431],
                      [-2.28539, 0.30825],
                      [-0.73095, -1.44001],
                      [2.12132, 1.09605],
                      [-2.71876, 0.99998],
                      [-2.85221, -0.21785],
                      [1.71876, -0.71873],
                      [1.85221, 0.49910]],

                     [[-0.67635, 4.19903],
                      [-2.78563, 2.58595],
                      [1.42635, -2.92168],
                      [3.53563, -1.30860],
                      [0.56193, 2.34784],
                      [-0.15655, 2.25204],
                      [0.46905, -2.43955],
                      [1.18753, -2.34374]],

                     [[-1.28586, 3.49625],
                      [-0.59915, -2.09615],
                      [1.99583, -1.77750],
                      [1.30911, 3.81490],
                      [3.01204, 2.26948],
                      [-2.26917, -0.98059],
                      [-1.46872, -2.28128],
                      [3.81249, 0.96879]],

                     [[-1.41473, 3.83861],
                      [-3.09740, 0.73739],
                      [2.85613, -2.49291],
                      [4.53881, 0.60831],
                      [0.47442, 2.73560],
                      [-1.46872, -3.00002],
                      [0.05683, -3.51685],
                      [1.99997, 2.21877]]]).cuda()

    # print(corners)

    indices_t = cir(corners.cpu()).reshape(-1, 3).cuda() 
    print('indices_t:', indices_t)
    
    '''
    indices = indices_t.unsqueeze(-1).repeat([1, 1, 2])
    
    # print('corners、indices:', corners.shape, indices.shape)
    
    points = torch.gather(corners, 1, indices)
    
    cir_centers = cir_tensor(points)
    
    print('corners[:, 0]:', points[:, 0])
    R = dist_tensor(cir_centers, points[:, 0])
    
    print(cir_centers.shape, R.shape)
    print(torch.cat([cir_centers, R.unsqueeze(1)], dim=1))
    # print(torch.gather(corners, 2, points))
    '''
