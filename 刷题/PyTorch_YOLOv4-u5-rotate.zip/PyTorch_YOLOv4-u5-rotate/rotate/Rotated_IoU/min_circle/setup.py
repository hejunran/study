from setuptools import setup
from torch.utils.cpp_extension import BuildExtension, CppExtension

setup(
    name='min_circle',  # 模块名称
    ext_modules=[CppExtension('min_circle', ['circle.cpp'])],
    cmdclass={
        'build_ext': BuildExtension
    }
)

