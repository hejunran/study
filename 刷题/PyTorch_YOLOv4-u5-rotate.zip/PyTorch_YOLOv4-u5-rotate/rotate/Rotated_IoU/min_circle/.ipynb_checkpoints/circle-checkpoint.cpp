﻿/*circle.cpp*/
#include "circle.h"
#include<iostream>
#include<algorithm>
#include<cmath>
#include<vector>
#define eps 1e-8
#define zero(a) fabs(a)<eps
using namespace std;
float R;
int n;
struct Point{
    float x,y;
    Point(){}
    Point(float tx,float ty){x=tx;y=ty;}
}p[8],central;

bool cmp(vector<float>  &p1, vector<float>  &p2){
	if(fabs(p1[0] - p2[0]) < eps && fabs(p1[1] - p2[1]) < eps){
		return true;
	}
	return false;
}


Point Circumcenter(Point a,Point b,Point c){
    float a1 = b.x - a.x, b1 = b.y - a.y, c1 = (a1*a1 + b1*b1)/2;
    float a2 = c.x - a.x, b2 = c.y - a.y, c2 = (a2*a2 + b2*b2)/2;
    float d = a1 * b2 - a2 * b1;
    return Point(a.x + (c1*b2 - c2*b1)/d,a.y + (a1*c2 - a2*c1)/d);
}

float dist(Point p1,Point p2){
    return sqrt((p1.x-p2.x)*(p1.x-p2.x)+(p1.y-p2.y)*(p1.y-p2.y));
}

void Min_cover_circle(){
    random_shuffle(p,p+n);
    central=p[0];R=0;
    for(int i=1;i<n;i++)
        if(dist(central,p[i])+eps>R){
            central=p[i];R=0;
            for(int j=0;j<i;j++)
                if(dist(central,p[j])+eps>R){
                    central.x=(p[i].x+p[j].x)/2;
                    central.y=(p[i].y+p[j].y)/2;
                    R=dist(central,p[j]);
                    for(int k=0;k<j;k++)
                        if(dist(central,p[k])+eps>R){
                            central=Circumcenter(p[i],p[j],p[k]);
                            R=dist(central,p[k]);
                        }
                }
        }
}

// part1:forward propagation
torch::Tensor Circle_forward_cpu(const torch::Tensor& points)
{
//    AT_ASSERTM(points.sizes()[0] == 8);
    int num = points.sizes()[0];
    torch::Tensor res = torch::zeros(num * 3);
    for(int j=0; j<num; j++) {
        const float* vertices = points.data_ptr<float>();

        vector<vector<float> > tmp;
        for(int i=0;i<8;i++){
            vector<float> v;
            v.push_back(vertices[j*8*2 + i*2 + 0]);
            v.push_back(vertices[j*8*2 + i*2 + 1]);
            tmp.push_back(v);
        }

        sort(tmp.begin(), tmp.end(), cmp);

        p[0].x = tmp[0][0];
        p[0].y = tmp[0][1];
        n = 1;
        for(int i=1;i<8;i++){
            if(fabs(tmp[i][0] - p[n-1].x) < eps && fabs(tmp[i][1] - p[n-1].y) < eps)
                continue;
            p[n].x = tmp[i][0];
            p[n].y = tmp[i][1];
            n++;
        }

        Min_cover_circle();
        res[j*3 + 0] = central.x;
        res[j*3 + 1] = central.y;
        res[j*3 + 2] = R;
    }
    return res;
}

// part3:pybind11 （将python与C++11进行绑定， 注意这里的forward，backward名称就是后来在python中可以引用的方法名）
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m){
    m.def("forward", &Circle_forward_cpu, "circle forward");
}
