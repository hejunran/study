/*circle.h*/
#include <torch/extension.h>
#include <vector>

// forward propagation
torch::Tensor Circle_forward_cpu(const torch::Tensor& points);