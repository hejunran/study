from torch.autograd import Function
import torch
import min_circle


class CircleFunction(Function):
    @staticmethod
    def forward(ctx, points):
        """
        It must accept a context ctx as the first argument, followed by any
        number of arguments (tensors or other types).
        The context can be used to store tensors that can be then retrieved
        during the backward pass."""
        cr = min_circle.forward(points)
        ctx.mark_non_differentiable(cr)
        return cr

    @staticmethod
    def backward(ctx, gradOutput):
        return ()


cir = CircleFunction.apply

gt_box = torch.Tensor([[[167.6769, 203.0333], [96.9672, 132.3216], [132.3231, 96.9667], [203.0328, 167.6784],
                       [132.3216, 203.0328], [96.9667, 167.6769], [167.6784, 96.9672], [203.0333, 132.3231]],
                      [[-4.08182e-03,  3.09350e+00], [-4.08186e-03,  3.09350e+00], [ 3.21555e-02, -8.08172e-01],
                        [ 3.21555e-02, -8.08172e-01], [ 1.95339e+00,  2.82037e+00],
                        [-1.14864e+00, -5.69802e-01], [-4.07787e-01, -1.24769e+00],
                        [ 2.69424e+00,  2.14248e+00]],])

# pred_box = torch.Tensor([[[132.3216, 203.0328], [96.9667, 167.6769], [167.6784, 96.9672], [203.0333, 132.3231]],
#                        [[167.6769, 203.0333], [96.9672, 132.3216], [132.3231, 96.9667], [203.0328, 167.6784]]])

corners1 = torch.tensor([[[375.76944, 196.8381], [299.35873, 196.74954], [299.40298, 158.57599], [375.8137, 158.66455]],
                         [[193.63158, 440.8105], [97.11263, 440.53156], [97.25099, 392.65155], [193.76993, 392.93048]],
                         [[269.7346, 481.18488], [148.03291, 479.69867], [148.7714, 419.22552], [270.47308, 420.71173]],
                         [[253.56708, 177.1853], [256.0, 196.0], [299.35873, 196.74954], [299.40298, 158.57599]],
                         ])

corners2 = torch.tensor([[[256., 196.], [253.56708, 177.1853], [371., 162.], [373.43292, 180.8147]],
                         [[68., 437.00003], [65.06067, 417.2892], [181., 400.00003], [183.93933, 419.71085]],
                         [[269.7346, 481.18488], [164.56836, 476.85358], [261., 392.99994], [272.43164, 406.14636]],
                         [[371.0, 162.0], [373.43292, 180.8147], [375.76944, 196.8381], [375.8137, 158.66455]]
                         ])

corners = torch.cat([corners1.cpu(), corners2.cpu()], dim=1)

# print(corners)

# print(cir(gt_box).reshape(-1, 3).cuda())
