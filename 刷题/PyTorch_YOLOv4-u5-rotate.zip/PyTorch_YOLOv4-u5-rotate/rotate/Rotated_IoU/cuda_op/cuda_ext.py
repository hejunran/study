import torch
from torch import nn
from torch.autograd import Function
import sort_vertices

class SortVertices(Function):
    @staticmethod
    def forward(ctx, vertices, mask, num_valid):
        idx = sort_vertices.sort_vertices_forward(vertices, mask, num_valid)
        ctx.mark_non_differentiable(idx)
        return idx
    
    @staticmethod
    def backward(ctx, gradout):
        return ()

sort_v = SortVertices.apply

if __name__ == "__main__":
    import time
    v = torch.tensor([[[[174.9998, 150.0005],
          [ 74.9998, 149.9995],
          [ 75.0002,  99.9995],
          [175.0002, 100.0005],
          [149.9995, 175.0002],
          [ 99.9995, 174.9998],
          [100.0005,  74.9998],
          [150.0005,  75.0002],
          [-25.0000, -25.0000],
          [ 99.9997, 149.9997],
          [-25.0000, -25.0000],
          [149.9998, 150.0002],
          [-25.0000, -25.0000],
          [-25.0000, -25.0000],
          [-25.0000, -25.0000],
          [-25.0000, -25.0000],
          [-25.0000, -25.0000],
          [100.0003,  99.9998],
          [-25.0000, -25.0000],
          [150.0002, 100.0003],
          [-25.0000, -25.0000],
          [-25.0000, -25.0000],
          [-25.0000, -25.0000],
          [-25.0000, -25.0000]]]]).cuda()
    # print('v.size()', v.shape)
    mean = torch.mean(v, dim=2, keepdim=True)
    v = v - mean
    m = torch.tensor([[[False, False, False, False, False, False, False, False, False,  True,
          False,  True, False, False, False, False, False,  True, False,  True,
          False, False, False, False]]]).cuda()
    nv = torch.sum(m.int(), dim=-1).int().cuda()
    # print('nv.size()', nv.shape)
    start = time.time()
    result = sort_v(v, m, nv)
    # torch.cuda.synchronize()
    # print("time: %.2f ms" % ((time.time() - start) * 1000))
    # print(result.size())
    # print(result)