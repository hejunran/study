import torch
import numpy as np
from numpy import pi as p3i
from rotate.Rotated_IoU.box_intersection_2d import oriented_box_intersection_2d
from rotate.Rotated_IoU.min_enclosing_box import smallest_bounding_box
from rotate.Rotated_IoU.min_circle.mc_ext import cir


def box_center_to_corners(b_, with_label=False):
    """
    Converts a set of oriented bounding boxes from
    centered representation (x_c, y_c, w, h, theta) to corner representation (x0, y0, ..., x3, y3).

    Arguments:
        b (Tensor[N, 6]): boxes to be converted. They are
            expected to be in (x_c, y_c, w, h, angle, [label]) format.
            :param b_: boxes
            :param with_label: Whether boxes have labels or not

    Returns:
        c (Tensor[N, 8]): converted boxes in (x0, y0, ..., x3, y3) format, where
            the corners are sorted counterclockwise.

    """
    b = b_.squeeze(0)
    if with_label:
        x_c, y_c, w, h, angle, label = b.unbind(-1)  # [N,]
    else:
        x_c, y_c, w, h, angle = b.unbind(-1)  # [N,]

    theta = angle * p3i / 180

    c = torch.cos(theta)
    s = torch.sin(theta)

    center = torch.stack([x_c, y_c], dim=-1).repeat(1, 4)  # [N, 8]

    dx = 0.5 * w
    dy = 0.5 * h
    c = c + 1e-5
    s = s + 1e-5
    cos = c / ((c ** 2 + s ** 2).sqrt() + 1e-10)
    sin = s / ((c ** 2 + s ** 2).sqrt() + 1e-10)

    dxcos = dx * cos
    dxsin = dx * sin
    dycos = dy * cos
    dysin = dy * sin

    dxy = [- dxcos - dysin, - dxsin + dycos,
           - dxcos + dysin, - dxsin - dycos,
           dxcos + dysin, dxsin - dycos,
           dxcos - dysin, dxsin + dycos]

    # corners = center + torch.stack(dxy, dim=-1)  # [N, 8]
    if with_label:
        corners = torch.cat([center + torch.stack(dxy, dim=-1), torch.unsqueeze(label, 1)], 1)
    else:
        corners = center + torch.stack(dxy, dim=-1)

    return corners.reshape([-1, 4, 2]).unsqueeze(0)  # [N, 8[+1]]


def cal_iou_single(box1: torch.Tensor, box2: torch.Tensor):
    """calculate iou

    Args:
        box1 (torch.Tensor): (1, N, 5)
        box2 (torch.Tensor): (1, N, 5)

    Returns:
        iou (torch.Tensor): (N)
    """
    if box1.shape[1] == 0:
        return torch.Tensor([]).cuda()
    corners1 = box_center_to_corners(box1)
    corners2 = box_center_to_corners(box2)
    inter_area, _ = oriented_box_intersection_2d(corners1, corners2)  # (B, N)
    area1 = box1[:, :, 2] * box1[:, :, 3]
    area2 = box2[:, :, 2] * box2[:, :, 3]
    u = torch.clamp(area1 + area2 - inter_area, min=1e-6)
    iou = inter_area / u
    return iou.squeeze(0)


def cal_iou_single_WH(box1_1: torch.Tensor, box2_1: torch.Tensor, enclosing_type: str = "smallest"):
    if box1_1.shape[1] == 0:
        return torch.Tensor([]).cuda()

    shape1 = box1_1.shape[0]
    shape2 = box2_1.shape[0]

    box1 = torch.repeat_interleave(box1_1, box2_1.shape[0], 0).unsqueeze(0)
    box2 = box2_1.repeat(box1_1.shape[0], 1).unsqueeze(0)

    corners1 = box_center_to_corners(box1)
    corners2 = box_center_to_corners(box2)
    inter_area, _ = oriented_box_intersection_2d(corners1, corners2)  # (B, N)
    area1 = box1[:, :, 2] * box1[:, :, 3]
    area2 = box2[:, :, 2] * box2[:, :, 3]
    u = torch.clamp(area1 + area2 - inter_area, min=1e-6)
    iou = inter_area / u
    return iou.squeeze(0).view(shape1, shape2)


def cal_iou(box1: torch.Tensor, box2: torch.Tensor):
    """calculate iou

    Args:
        box1 (torch.Tensor): (1, N, 5)
        box2 (torch.Tensor): (1, N, 5)
    
    Returns:
        iou (torch.Tensor): (N)
        corners1 (torch.Tensor): (1, N, 4, 2)
        corners1 (torch.Tensor): (1, N, 4, 2)
        U (torch.Tensor): (1, N) area1 + area2 - inter_area
    """
    corners1 = box_center_to_corners(box1)
    corners2 = box_center_to_corners(box2)
    inter_area, _ = oriented_box_intersection_2d(corners1, corners2)  # (B, N)
    area1 = box1[:, :, 2] * box1[:, :, 3]
    area2 = box2[:, :, 2] * box2[:, :, 3]
    u = torch.clamp(area1 + area2 - inter_area, min=1e-6)
    iou = inter_area / u
    return iou, corners1, corners2, u


def cal_wha_iou(box1_1: torch.Tensor, box2_1: torch.Tensor):
    """calculate iou

    Args:
        box1_ (torch.Tensor): (1, N, 5)
        box2_ (torch.Tensor): (1, N, 5)

    Returns:
        iou (torch.Tensor): (N)
        corners1 (torch.Tensor): (1, N, 4, 2)
        corners1 (torch.Tensor): (1, N, 4, 2)
        U (torch.Tensor): (1, N) area1 + area2 - inter_area
    """
    shape1 = box1_1.shape[0]
    shape2 = box2_1.shape[0]

    zero1 = torch.zeros(shape1, 2).to(box1_1.device)
    zero2 = torch.zeros(shape2, 2).to(box2_1.device)

    box1_2 = torch.cat((zero1, box1_1), dim=1)
    box2_2 = torch.cat((zero2, box2_1), dim=1)

    box1 = torch.repeat_interleave(box1_2, box2_2.shape[0], 0).unsqueeze(0)
    box2 = box2_2.repeat(box1_2.shape[0], 1).unsqueeze(0)

    corners1 = box_center_to_corners(box1)
    corners2 = box_center_to_corners(box2)
    inter_area, _ = oriented_box_intersection_2d(corners1, corners2)  # (B, N)
    area1 = box1[:, :, 2] * box1[:, :, 3]
    area2 = box2[:, :, 2] * box2[:, :, 3]
    u = inter_area / torch.clamp(area1 + area2 - inter_area, min=1e-6)
    return u.squeeze(0).view(shape1, shape2)


def cal_hbb_iou(_box_a: torch.Tensor, _box_b: torch.Tensor):
    """calculate iou

    Args:
        box1_ (torch.Tensor): (N, 2)
        box2_ (torch.Tensor): (N, 2)

    Returns:
        iou (torch.Tensor): (N)
    """
    print('_box_a:', _box_a.shape)
    print('_box_b:', _box_b.shape)
    b1_x1, b1_x2 = _box_a[:, 0] - _box_a[:, 2] / 2, _box_a[:, 0] + _box_a[:, 2] / 2
    b1_y1, b1_y2 = _box_a[:, 1] - _box_a[:, 3] / 2, _box_a[:, 1] + _box_a[:, 3] / 2
    b2_x1, b2_x2 = _box_b[:, 0] - _box_b[:, 2] / 2, _box_b[:, 0] + _box_b[:, 2] / 2
    b2_y1, b2_y2 = _box_b[:, 1] - _box_b[:, 3] / 2, _box_b[:, 1] + _box_b[:, 3] / 2
    box_a = torch.zeros_like(_box_a)
    box_b = torch.zeros_like(_box_b)
    box_a[:, 0], box_a[:, 1], box_a[:, 2], box_a[:, 3] = b1_x1, b1_y1, b1_x2, b1_y2
    box_b[:, 0], box_b[:, 1], box_b[:, 2], box_b[:, 3] = b2_x1, b2_y1, b2_x2, b2_y2
    A = box_a.size(0)
    B = box_b.size(0)
    max_xy = torch.min(box_a[:, 2:].unsqueeze(1).expand(A, B, 2),
                       box_b[:, 2:].unsqueeze(0).expand(A, B, 2))
    min_xy = torch.max(box_a[:, :2].unsqueeze(1).expand(A, B, 2),
                       box_b[:, :2].unsqueeze(0).expand(A, B, 2))
    inter = torch.clamp((max_xy - min_xy), min=0)

    inter = inter[:, :, 0] * inter[:, :, 1]
    # 计算先验框和真实框各自的面积
    area_a = ((box_a[:, 2] - box_a[:, 0]) *
              (box_a[:, 3] - box_a[:, 1])).unsqueeze(1).expand_as(inter)  # [A,B]
    area_b = ((box_b[:, 2] - box_b[:, 0]) *
              (box_b[:, 3] - box_b[:, 1])).unsqueeze(0).expand_as(inter)  # [A,B]
    # 求IOU
    union = area_a + area_b - inter
    return inter / union  # [A,B]


def cal_diou(box1: torch.Tensor, box2: torch.Tensor, enclosing_type: str = "smallest"):
    """calculate diou loss

    Args:
        box1 (torch.Tensor): [description]
        box2 (torch.Tensor): [description]
    """
    if box1.shape[1] == 0:
        return torch.Tensor([]).cuda()
    iou, corners1, corners2, u = cal_iou(box1, box2)
    w, h = enclosing_box(corners1, corners2, enclosing_type)
    c2 = w * w + h * h  # (B, N)
    x_offset = box1[..., 0] - box2[..., 0]
    y_offset = box1[..., 1] - box2[..., 1]
    d2 = x_offset * x_offset + y_offset * y_offset
    diou = iou - 1.0 * d2 / torch.clamp(c2, min=1e-6)
    return diou.squeeze(0)


def cal_giou(box1, box2, enclosing_type="smallest"):
    if box1.shape[1] == 0:
        return torch.Tensor([]).cuda()
    iou, corners1, corners2, u = cal_iou(box1, box2)
    w, h = enclosing_box(corners1, corners2, enclosing_type)
    area_c = w * h
    giou = iou - (area_c - u) / torch.clamp(area_c, min=1e-6)
    return giou.squeeze(0)


def cal_giou_NM(box1_1: torch.Tensor, box2_1: torch.Tensor, enclosing_type: str = "smallest"):
    if box1_1.shape[1] == 0:
        return torch.Tensor([]).cuda()

    shape1 = box1_1.shape[0]
    shape2 = box2_1.shape[0]

    box1 = torch.repeat_interleave(box1_1, box2_1.shape[0], 0).unsqueeze(0)
    box2 = box2_1.repeat(box1_1.shape[0], 1).unsqueeze(0)

    iou, corners1, corners2, u = cal_iou(box1, box2)
    w, h = enclosing_box(corners1, corners2, enclosing_type)
    area_c = w * h
    giou = iou - (area_c - u) / torch.clamp(area_c, min=1e-6)
    return giou.squeeze(0).view(shape1, shape2)


def cal_ciou(box1: torch.Tensor, box2: torch.Tensor, enclosing_type: str = "smallest"):
    if box1.shape[1] == 0:
        return torch.Tensor([]).cuda()
    iou, corners1, corners2, u = cal_iou(box1, box2)
    w, h = enclosing_box(corners1, corners2, enclosing_type)
    c2 = w * w + h * h  # (B, N)
    x_offset = box1[..., 0] - box2[..., 0]
    y_offset = box1[..., 1] - box2[..., 1]
    d2 = x_offset * x_offset + y_offset * y_offset

    v = (4 / (np.pi ** 2)) * torch.pow((torch.atan(box2[..., 2] / torch.clamp(box2[..., 3], min=1e-6)) -
                                        torch.atan(box1[..., 2] / torch.clamp(box1[..., 3], min=1e-6))), 2)

    alpha = v / torch.clamp((1 - iou + v), min=1e-6)

    # ar = (8 / (np.pi ** 2)) * arctan * ((box1[..., 2] - 2 * box1[..., 2]) * box1[..., 3])

    diou = iou - 1.0 * (d2 / torch.clamp(c2, min=1e-6) + alpha * v)
    # diou = iou - (d2 / c2 + alpha * ar)

    return diou.squeeze(0)


# pred, gt
def cal_rciou(box1: torch.Tensor, box2: torch.Tensor):
    corners1 = box_center_to_corners(box1.unsqueeze(0)).squeeze(0)
    corners2 = box_center_to_corners(box2.unsqueeze(0)).squeeze(0)

    iou = cal_iou_single(box1.unsqueeze(0), box2.unsqueeze(0))
    # print('torch.cat([corners1.cpu(), corners2.cpu()], dim=1):', torch.cat([corners1.cpu(), corners2.cpu()], dim=1))
    xyr = cir(torch.cat([corners1.cpu(), corners2.cpu()], dim=1)).reshape(-1, 3).cuda()
    # print("xyr:", xyr)

    # print('box1[..., 0] :', box1[..., 0])
    # print('box2[..., 0] :', box2[..., 0])
    # print('box1[..., 1] :', box1[..., 1])
    # print('box2[..., 1] :', box2[..., 1])
    dis = torch.pow((box1[..., 0] - box2[..., 0]), 2) + torch.pow((box1[..., 1] - box2[..., 1]), 2)
    # dis = torch.pow((box1[..., 0] - xyr[..., 0]), 2) + torch.pow((box1[..., 1] - xyr[..., 1]), 2)
    cc = torch.pow((box2[..., 0] - xyr[..., 0]), 2) + torch.pow((box2[..., 1] - xyr[..., 1]), 2)

    v = (4 / (np.pi ** 2)) * torch.pow((torch.atan(box2[..., 2] / torch.clamp(box2[..., 3], min=1e-6)) -
                                        torch.atan(box1[..., 2] / torch.clamp(box1[..., 3], min=1e-6))), 2)

    alpha = v / torch.clamp((1 - iou + v), min=1e-6)

    rciou = iou - 1.0 * (dis / torch.clamp(torch.pow(2 * xyr[..., 2], 2), min=1e-6))  # 1
    # rciou = iou - 1.0 * (dis / torch.clamp(torch.pow(2 * xyr[..., 2], 2), min=1e-6) + alpha * v)  # 2
    # rciou = iou - 1.0 * ((dis + cc) / torch.clamp(torch.pow(2 * xyr[..., 2], 2), min=1e-6))  # 3
    # rciou = iou - 1.0 * ((dis / torch.clamp(torch.pow(2 * xyr[..., 2], 2), min=1e-6)) + (
    #            cc / torch.clamp(torch.pow(xyr[..., 2], 2), min=1e-6)))  # 3+
    # rciou = iou - 1.0 * ((dis / torch.clamp(torch.pow(2 * xyr[..., 2], 2), min=1e-6)) + (
    #         cc / torch.clamp(torch.pow(xyr[..., 2], 2), min=1e-6)) + alpha * v)  # 4
    return rciou


def cal_giou_edge(box1, box2, enclosing_type="smallest"):
    if box1.shape[1] == 0:
        return torch.Tensor([]).cuda()
    iou, corners1, corners2, u = cal_iou(box1, box2)
    w, h = enclosing_box(corners1, corners2, enclosing_type)
    area_c = w * h

    x1_pred, y1_pred = corners1[:, 0, 0], corners1[:, 0, 1]
    x2_pred, y2_pred = corners1[:, 1, 0], corners1[:, 1, 1]

    a_pred = x2_pred - x1_pred
    b_pred = y2_pred - y1_pred
    # c_pred = x1_pred * y2_pred - x2_pred * y1_pred

    x1_gt, y1_gt = corners2[:, 0, 0], corners2[:, 0, 1]
    x2_gt, y2_gt = corners2[:, 1, 0], corners2[:, 1, 1]

    a_gt = x2_gt - x1_gt
    b_gt = y2_gt - y1_gt
    # c_gt = x1_gt * y2_gt - x2_gt * y1_gt

    cos_angle = torch.abs(a_pred * a_gt + b_pred * b_gt) / (
            torch.sqrt(torch.pow(a_pred, 2) + torch.pow(b_pred, 2)) * torch.sqrt(
        torch.pow(a_gt, 2) + torch.pow(b_gt, 2)))

    ones = torch.ones(cos_angle.shape, requires_grad=False, device='cuda:0')

    angle_loss = ones - torch.clamp(cos_angle, min=-1, max=1)
    # print('cos_angle:', cos_angle)00000
    # 角度归一化
    # radius = torch.acos(cos_angle)
    # print('radius:', radius)
    # angle = 0.5 * ((radius * 180 / np.pi) / 90)
    # angle = 0.5 * (radius * 2 / np.pi)
    # print('angle:', angle)

    giou = iou - ((area_c - u) / torch.clamp(area_c, min=1e-6) + 0.5 * angle_loss.unsqueeze(0))

    return giou.squeeze(0)


# pred, gt
def cal_rciou_edge(box1: torch.Tensor, box2: torch.Tensor, rc):
    if torch.isnan(box1).any():
        print('box1:', box1)

    if torch.isnan(box2).any():
        print('box2:', box2)

    # 超出边界的角度范围在[-180, -90)
    # box1[:, 4] = torch.where(box1[:, 4] <= -90, box1[:, 4] + 90, box1[:, 4])

    # 超出边界的角度范围
    # box1[:, 4] = torch.where(torch.abs(box1[:, 4]) % 180 <= 90,
    #                          -torch.abs(box1[:, 4]) % 180,
    #                          -180 + torch.abs(box1[:, 4]) % 180)

    corners1 = box_center_to_corners(box1.unsqueeze(0)).squeeze(0)
    corners2 = box_center_to_corners(box2.unsqueeze(0)).squeeze(0)

    """
    w1h = box1[:, 2].le(box1[:, 3])
    x1_pred, y1_pred = torch.where(w1h, corners1[:, 0, 0], corners1[:, 1, 0]), \
                       torch.where(w1h, corners1[:, 0, 1], corners1[:, 1, 1])

    x2_pred, y2_pred = torch.where(w1h, corners1[:, 1, 0], corners1[:, 2, 0]), \
                       torch.where(w1h, corners1[:, 1, 1], corners1[:, 2, 1])                 
    
    """
    x1_pred, y1_pred = corners1[:, 0, 0], corners1[:, 0, 1]
    x2_pred, y2_pred = corners1[:, 1, 0], corners1[:, 1, 1]

    a_pred = x2_pred - x1_pred
    b_pred = y2_pred - y1_pred

    if torch.isnan(a_pred).any():
        print('a_pred:', a_pred)

    if torch.isnan(b_pred).any():
        print('b_pred:', b_pred)

    """
    w2h = box2[:, 2].le(box2[:, 3])
    x1_gt, y1_gt = torch.where(w2h, corners2[:, 0, 0], corners2[:, 1, 0]), \
                   torch.where(w2h, corners2[:, 0, 1], corners2[:, 1, 1])

    x2_gt, y2_gt = torch.where(w2h, corners2[:, 1, 0], corners2[:, 2, 0]), \
                   torch.where(w2h, corners2[:, 1, 1], corners2[:, 2, 1])            
 
    """
    x1_gt, y1_gt = corners2[:, 0, 0], corners2[:, 0, 1]
    x2_gt, y2_gt = corners2[:, 1, 0], corners2[:, 1, 1]

    a_gt = x2_gt - x1_gt
    b_gt = y2_gt - y1_gt
    # c_gt = x1_gt * y2_gt - x2_gt * y1_gt

    if torch.isnan(a_gt).any():
        print('a_gt:', a_gt)

    if torch.isnan(b_gt).any():
        print('b_gt:', b_gt)

    ################################
    # TODO COS
    ################################
    cos_angle_ = torch.clamp(torch.abs(a_pred * a_gt + b_pred * b_gt) / torch.clamp(
        torch.sqrt(torch.pow(a_pred, 2) + torch.pow(b_pred, 2)) * torch.sqrt(
            torch.pow(a_gt, 2) + torch.pow(b_gt, 2)), min=1e-6), min=-1, max=1)

    if torch.isnan(cos_angle_).any():
        print('torch.abs:', torch.abs(a_pred * a_gt + b_pred * b_gt))
        print('torch.sqrt:', torch.sqrt(torch.pow(a_pred, 2) + torch.pow(b_pred, 2)) * torch.sqrt(
            torch.pow(a_gt, 2) + torch.pow(b_gt, 2)))
        print('cos_angle_:', cos_angle_)

    one = torch.ones(cos_angle_.shape, requires_grad=False, device=cos_angle_.device)
    cos_angle = one - cos_angle_

    iou = cal_iou_single(box1.unsqueeze(0), box2.unsqueeze(0))

    if torch.isnan(iou).any():
        print('iou:', iou)

    corners = torch.cat([corners1, corners2], dim=1)

    xyr = cir(corners.cpu()).reshape(-1, 3).cuda()

    if torch.isnan(xyr).any():
        print('xyr:', xyr)

    dis = torch.pow((box1[..., 0] - box2[..., 0]), 2) + torch.pow((box1[..., 1] - box2[..., 1]), 2)
    # dis = torch.sqrt(torch.pow((box1[..., 0] - box2[..., 0]), 2) + torch.pow((box1[..., 1] - box2[..., 1]), 2))

    dis_loss = dis / torch.clamp(torch.pow(2 * xyr[..., 2], 2), min=1e-6)
    # dis_loss = dis / torch.clamp(2 * xyr[..., 2], min=1e-6)

    index = torch.le(dis_loss, 1)
    if dis_loss[index].shape[0] < dis_loss.shape[0]:
        print('corners:', corners)
        print('dis:', dis)
        print('xyr:', xyr)
        print('dis_loss:', dis_loss)

    angle_loss = rc * cos_angle

    """
    alter_box1 = torch.cat([box1[:, :4], box2[:, 4].unsqueeze(1)], dim=1)

    obb_iou = cal_iou_single(alter_box1.unsqueeze(0), box2.unsqueeze(0))

    # if torch.gt(hbb_iou.mean(), 0.9) and torch.gt(iou.mean(), 0.5):
    if torch.gt(obb_iou.mean(), 0.95):

        rciou = iou - angle_loss  # 1

    else:
        rciou = iou - dis_loss  # 1
    """
    """
    if rc==0:
        rciou = iou - dis_loss  # 1
    else:
        rciou = iou - angle_loss  # 2
    """

    # rciou = iou - (dis_loss * angle_loss)
    rciou = iou - (dis_loss + angle_loss)
    # rciou = iou - 0.3 * dis_loss
    # rciou = iou - 0 * dis_loss

    if torch.isnan(rciou).any():
        print('rciou:', rciou)

    return rciou, iou, dis_loss, angle_loss


def get_circumscribed_circle_R(anchors_corners):

    #######################################
    # TODO 重复数组，获取2点确定的圆的所有情况
    #######################################
    anchors_corners_2_x = anchors_corners.repeat_interleave(8, 1)

    anchors_corners_2_y = anchors_corners.repeat_interleave(8, 0).reshape(anchors_corners.shape[0], -1, 2)

    anchors_corners_2_xy = torch.cat((anchors_corners_2_x, anchors_corners_2_y), dim=2). \
        reshape(anchors_corners.shape[0], -1, 2, 2)

    # 获取所有圆的圆心和半径
    circle_2_point = (anchors_corners_2_xy[:, :, 0, :] + anchors_corners_2_xy[:, :, 1, :]) / 2

    circle_2_r = torch.sum(torch.pow((anchors_corners_2_xy[:, :, 0, :] - circle_2_point), 2), dim=2)

    # 获取有效的外接圆圆心，筛除相同的点
    circle_2_point_mask = torch.sum(torch.pow((anchors_corners_2_xy[:, :, 0, :] - anchors_corners_2_xy[:, :, 1, :]), 2),
                                    dim=2).le(1e-6)

    circle_2_point_vaild = circle_2_point[~circle_2_point_mask].reshape(anchors_corners.shape[0], -1, 2)

    #######################################
    # TODO 重复数组，获取3点确定的圆的所有情况
    #######################################
    anchors_corners_3_x = anchors_corners_2_x.repeat_interleave(8, 1).unsqueeze(-2)

    anchors_corners_3_y = anchors_corners_2_xy.repeat_interleave(8, 0).reshape(anchors_corners.shape[0], -1, 2, 2)

    anchors_corners_3_xy = torch.cat((anchors_corners_3_x, anchors_corners_3_y), dim=2)

    # 三点中垂线，第一条中垂线A1*x + B1*y = C1
    # circle_plumb_line_1 = (anchors_corners_3_xy[:, :, 0, :] + anchors_corners_3_xy[:, :, 1, :]) / 2

    # AB1
    circle_plumb_line_1_AB = anchors_corners_3_xy[:, :, 1, :] - anchors_corners_3_xy[:, :, 0, :]
    # C1
    circle_plumb_line_1_C1 = torch.sum(torch.pow(anchors_corners_3_xy[:, :, 1, :], 2) -
                                       torch.pow(anchors_corners_3_xy[:, :, 0, :], 2), dim=2) / 2

    # 三点中垂线，第二条中垂线A2*x + B2*y = C2
    # circle_plumb_line_2 = (anchors_corners_3_xy[:, :, 1, :] + anchors_corners_3_xy[:, :, 2, :]) / 2

    # AB2
    circle_plumb_line_2_AB = anchors_corners_3_xy[:, :, 2, :] - anchors_corners_3_xy[:, :, 1, :]
    # C2
    circle_plumb_line_2_C2 = torch.sum(torch.pow(anchors_corners_3_xy[:, :, 2, :], 2) -
                                       torch.pow(anchors_corners_3_xy[:, :, 1, :], 2), dim=2) / 2

    # 如果delta=0，说明两直线平行，三点共线
    delta = circle_plumb_line_1_AB[:, :, 0] * circle_plumb_line_2_AB[:, :, 1] - \
            circle_plumb_line_2_AB[:, :, 0] * circle_plumb_line_1_AB[:, :, 1]

    # 若如果delta不等于0，则求交点
    intersection_point_of_plumb_line_x = ((circle_plumb_line_2_AB[:, :, 1] * circle_plumb_line_1_C1 -
                                           circle_plumb_line_1_AB[:, :, 1] * circle_plumb_line_2_C2) / delta).unsqueeze(
        -1)
    intersection_point_of_plumb_line_y = ((circle_plumb_line_1_AB[:, :, 0] * circle_plumb_line_2_C2 -
                                           circle_plumb_line_2_AB[:, :, 0] * circle_plumb_line_1_C1) / delta).unsqueeze(
        -1)

    circle_3_point = torch.cat((intersection_point_of_plumb_line_x, intersection_point_of_plumb_line_y), dim=2)

    circle_3_r = torch.sum(torch.pow((anchors_corners_3_xy[:, :, 0, :] - circle_3_point), 2), dim=2)

    circle_3_point_mask = torch.pow(((anchors_corners_3_xy[:, :, 2, 1] - anchors_corners_3_xy[:, :, 0, 1]) *
                           (anchors_corners_3_xy[:, :, 1, 0] - anchors_corners_3_xy[:, :, 0, 0]) -
                           (anchors_corners_3_xy[:, :, 1, 1] - anchors_corners_3_xy[:, :, 0, 1]) *
                           (anchors_corners_3_xy[:, :, 2, 0] - anchors_corners_3_xy[:, :, 0, 0])), 2).le(1e-12)

    circle_3_point_vaild = circle_3_point[~circle_3_point_mask].reshape(anchors_corners.shape[0], -1, 2)

    # 两点和三点确定外接圆的所有情况
    circle_all_point = torch.cat((circle_2_point_vaild,circle_3_point_vaild), dim=1)

    circle_all_r = torch.cat((circle_2_r[~circle_2_point_mask].reshape(anchors_corners.shape[0], -1),
                              circle_3_r[~circle_3_point_mask].reshape(anchors_corners.shape[0], -1)), dim=1)

    # 判断anchors_corners中的点是否都在所得外接圆内
    anchors_corners_rp = anchors_corners.unsqueeze(1).repeat_interleave(circle_all_point.shape[1], 1). \
        reshape(anchors_corners.shape[0], -1, 2)

    circle_all_point_rp = circle_all_point.repeat_interleave(anchors_corners.shape[1], 1)

    circle_all_r_rp = circle_all_r.repeat_interleave(anchors_corners.shape[1], 1)

    circle_all_dis = torch.sum(torch.pow((anchors_corners_rp - circle_all_point_rp), 2), dim=2)

    is_less_circle_r = circle_all_dis.le(circle_all_r_rp + 0.005).reshape(anchors_corners.shape[0], -1, 8)

    t_sum = torch.sum(is_less_circle_r, dim=2)
    t_eq = t_sum.eq(8)

    # maxR = torch.max(circle_all_r)
    circle_all_r[~t_eq] = 1e18

    min_circle_r2, min_circle_r2_idx = torch.min(circle_all_r, dim=1)
    return torch.sqrt(min_circle_r2).detach()
    # return torch.sqrt(min_circle_r2)


# pred, gt
def cal_rciou_edge_py(box1: torch.Tensor, box2: torch.Tensor, rc=0.5):
    if torch.isnan(box1).any():
        print('box1:', box1)

    if torch.isnan(box2).any():
        print('box2:', box2)

    corners1 = box_center_to_corners(box1.unsqueeze(0)).squeeze(0)
    corners2 = box_center_to_corners(box2.unsqueeze(0)).squeeze(0)

    x1_pred, y1_pred = corners1[:, 0, 0], corners1[:, 0, 1]
    x2_pred, y2_pred = corners1[:, 1, 0], corners1[:, 1, 1]

    a_pred = x2_pred - x1_pred
    b_pred = y2_pred - y1_pred
    # c_pred = x1_pred * y2_pred - x2_pred * y1_pred

    if torch.isnan(a_pred).any():
        print('a_pred:', a_pred)

    if torch.isnan(b_pred).any():
        print('b_pred:', b_pred)

    x1_gt, y1_gt = corners2[:, 0, 0], corners2[:, 0, 1]
    x2_gt, y2_gt = corners2[:, 1, 0], corners2[:, 1, 1]

    a_gt = x2_gt - x1_gt
    b_gt = y2_gt - y1_gt
    # c_gt = x1_gt * y2_gt - x2_gt * y1_gt

    if torch.isnan(a_gt).any():
        print('a_gt:', a_gt)

    if torch.isnan(b_gt).any():
        print('b_gt:', b_gt)

    cos_angle_ = torch.clamp(torch.abs(a_pred * a_gt + b_pred * b_gt) / torch.clamp(
        torch.sqrt(torch.pow(a_pred, 2) + torch.pow(b_pred, 2)) * torch.sqrt(
            torch.pow(a_gt, 2) + torch.pow(b_gt, 2)), min=1e-6), min=-1, max=1)

    if torch.isnan(cos_angle_).any():
        print('torch.abs:', torch.abs(a_pred * a_gt + b_pred * b_gt))
        print('torch.sqrt:', torch.sqrt(torch.pow(a_pred, 2) + torch.pow(b_pred, 2)) * torch.sqrt(
            torch.pow(a_gt, 2) + torch.pow(b_gt, 2)))
        print('cos_angle_:', cos_angle_)

    one = torch.ones(cos_angle_.shape, requires_grad=False, device=cos_angle_.device)

    cos_angle = one - cos_angle_

    iou = cal_iou_single(box1.unsqueeze(0), box2.unsqueeze(0))

    if torch.isnan(iou).any():
        print('iou:', iou)

    corners = torch.cat([corners1, corners2], dim=1)

    circumscribed_circler_R = get_circumscribed_circle_R(corners)

    if torch.isnan(circumscribed_circler_R).any():
        print('xyr:', circumscribed_circler_R)

    # dis = torch.pow((box1[..., 0] - box2[..., 0]), 2) + torch.pow((box1[..., 1] - box2[..., 1]), 2)
    dis = torch.sqrt(torch.pow((box1[..., 0] - box2[..., 0]), 2) + torch.pow((box1[..., 1] - box2[..., 1]), 2))

    # dis_loss = dis / torch.clamp(torch.pow(2 * xyr[..., 2], 2), min=1e-6)
    dis_loss = dis / torch.clamp(2 * circumscribed_circler_R, min=1e-6)

    index = torch.le(dis_loss, 1)

    if dis_loss[index].shape[0] < dis_loss.shape[0]:
        print('corners:', corners)
        print('dis:', dis)
        print('circumscribed_circler_R:', circumscribed_circler_R)
        print('dis_loss:', dis_loss)

    angle_loss = rc * cos_angle

    #############################################
    # TODO 第一种方法
    #############################################
    rciou = iou - 1.0 * (dis_loss + angle_loss)  # 1

    return rciou, iou, dis_loss, angle_loss


# pred, gt
def cal_rciou_edge_improve(box1: torch.Tensor, box2: torch.Tensor, rc):
    corners1 = box_center_to_corners(box1.unsqueeze(0)).squeeze(0)
    corners2 = box_center_to_corners(box2.unsqueeze(0)).squeeze(0)

    ################################
    # TODO 预测框和真实框的夹角
    ################################
    x1_pred, y1_pred = corners1[:, 0, 0], corners1[:, 0, 1]
    x2_pred, y2_pred = corners1[:, 1, 0], corners1[:, 1, 1]

    a_pred = x2_pred - x1_pred
    b_pred = y2_pred - y1_pred

    x1_gt, y1_gt = corners2[:, 0, 0], corners2[:, 0, 1]
    x2_gt, y2_gt = corners2[:, 1, 0], corners2[:, 1, 1]

    a_gt = x2_gt - x1_gt
    b_gt = y2_gt - y1_gt

    ################################
    # TODO SIN
    ################################
    sin_angle = torch.clamp(torch.abs(a_pred * b_gt + b_pred * a_gt) / (
            torch.sqrt(torch.pow(a_pred, 2) + torch.pow(b_pred, 2)) * torch.sqrt(
        torch.pow(a_gt, 2) + torch.pow(b_gt, 2))), min=-1, max=1)

    ################################
    # TODO SIN_SQUARE
    ################################
    sin_angle_square = torch.clamp(
        torch.pow(a_pred * b_gt + b_pred * a_gt, 2) / ((torch.pow(a_pred, 2) + torch.pow(b_pred, 2)) * (
                torch.pow(a_gt, 2) + torch.pow(b_gt, 2))), max=1)

    ################################
    # TODO COS
    ################################
    cos_angle_ = torch.clamp(torch.abs(a_pred * a_gt + b_pred * b_gt) / (
            torch.sqrt(torch.pow(a_pred, 2) + torch.pow(b_pred, 2)) * torch.sqrt(
        torch.pow(a_gt, 2) + torch.pow(b_gt, 2))), min=-1, max=1)

    ################################
    # TODO COS_SQUARE
    ################################
    cos_angle_square = torch.clamp(
        torch.pow(a_pred * a_gt + b_pred * b_gt, 2) / ((torch.pow(a_pred, 2) + torch.pow(b_pred, 2)) * (
                torch.pow(a_gt, 2) + torch.pow(b_gt, 2))), max=1)

    one = torch.ones(cos_angle_.shape, requires_grad=False, device=cos_angle_.device)
    cos_angle = one - cos_angle_

    iou = cal_iou_single(box1.unsqueeze(0), box2.unsqueeze(0))
    xyr = cir(torch.cat([corners1.cpu(), corners2.cpu()], dim=1)).reshape(-1, 3).cuda()
    # print("xyr:", xyr)

    print('shape:', box1.shape, box2.shape, xyr.shape)
    ################################
    # TODO 真实框和圆心与预测框所成夹角  pre box1:(x, y, w, h, theta) , gt box2:(x, y, w, h, theta) , xyr: (x, y, r)
    ################################
    # C1
    pre_center_x1, pre_center_y1 = box1[:, 0], box1[:, 1]
    # C2
    gt_center_x1, gt_center_y1 = box2[:, 0], box2[:, 1]
    # C3
    cir_center_x1, cir_center_y1 = xyr[:, 0], xyr[:, 1]

    L12_x = pre_center_x1 - gt_center_x1
    L12_y = pre_center_y1 - gt_center_y1

    # L23_x = cir_center_x1 - gt_center_x1
    # L23_y = cir_center_y1 - gt_center_y1

    L13_x = pre_center_x1 - cir_center_x1
    L13_y = pre_center_y1 - cir_center_y1

    dis = torch.pow((box1[..., 0] - box2[..., 0]), 2) + torch.pow((box1[..., 1] - box2[..., 1]), 2)

    # if (torch.pow(L12_x, 2) + torch.pow(L12_y, 2)) != 0 and (torch.pow(L23_x, 2) + torch.pow(L23_y, 2)) != 0 and (
    #         torch.pow(L13_x, 2) + torch.pow(L13_y, 2)) != 0:
    # c2_cos_angle_ = torch.clamp(torch.abs(L12_x * L23_x + L12_y * L23_y) / torch.clamp(
    #         torch.sqrt(torch.pow(L12_x, 2) + torch.pow(L12_y, 2)) * torch.sqrt(
    #     torch.pow(L23_x, 2) + torch.pow(L23_y, 2)), min=1e-6), min=-1, max=1)
    #
    # c2_cos_angle = one - c2_cos_angle_

    ################################
    # TODO 预测框和圆心与真实框所成夹角
    ################################
    c1_cos_angle_ = torch.clamp(torch.abs(L12_x * L13_x + L12_y * L13_y) / torch.clamp(
        torch.sqrt(torch.pow(L12_x, 2) + torch.pow(L12_y, 2)) * torch.sqrt(
            torch.pow(L13_x, 2) + torch.pow(L13_y, 2)), min=1e-6), min=-1, max=1)

    c1_cos_angle = one - c1_cos_angle_

    angle_loss = cos_angle + c1_cos_angle

    rciou = iou - 1.0 * (dis / torch.clamp(torch.pow(2 * xyr[..., 2], 2), min=1e-6) + rc * angle_loss)  # 1

    # else:
    #     rciou = iou - 1.0 * (dis / torch.clamp(torch.pow(2 * xyr[..., 2], 2), min=1e-6) + rc * cos_angle)  # 1

    # rciou = iou - 1.0 * ((dis + cc) / torch.clamp(torch.pow(2 * xyr[..., 2], 2), min=1e-6))  # 3
    # rciou = iou - 1.0 * ((dis / torch.clamp(torch.pow(2 * xyr[..., 2], 2), min=1e-6)) + (
    #         cc / torch.clamp(torch.pow(xyr[..., 2], 2), min=1e-6)) + rc * cos_angle)  # 3+
    return rciou


def cal_iou_3d(box3d1: torch.Tensor, box3d2: torch.Tensor, verbose=False):
    """calculated 3d iou. assume the 3d bounding boxes are only rotated around z axis

    Args:
        box3d1 (torch.Tensor): (B, N, 3+3+1),  (x,y,z,w,h,l,alpha)
        box3d2 (torch.Tensor): (B, N, 3+3+1),  (x,y,z,w,h,l,alpha)
    """
    box1 = box3d1[..., [0, 1, 3, 4, 6]]  # 2d box
    box2 = box3d2[..., [0, 1, 3, 4, 6]]
    zmax1 = box3d1[..., 2] + box3d1[..., 5] * 0.5
    zmin1 = box3d1[..., 2] - box3d1[..., 5] * 0.5
    zmax2 = box3d2[..., 2] + box3d2[..., 5] * 0.5
    zmin2 = box3d2[..., 2] - box3d2[..., 5] * 0.5
    z_overlap = (torch.min(zmax1, zmax2) - torch.max(zmin1, zmin2)).clamp_min(0.)
    iou_2d, corners1, corners2, u = cal_iou(box1, box2)  # (B, N)
    intersection_3d = iou_2d * u * z_overlap
    v1 = box3d1[..., 3] * box3d1[..., 4] * box3d1[..., 5]
    v2 = box3d2[..., 3] * box3d2[..., 4] * box3d2[..., 5]
    u3d = v1 + v2 - intersection_3d
    if verbose:
        z_range = (torch.max(zmax1, zmax2) - torch.min(zmin1, zmin2)).clamp_min(0.)
        return intersection_3d / u3d, corners1, corners2, z_range, u3d
    else:
        return intersection_3d / u3d


def cal_giou_3d(box3d1: torch.Tensor, box3d2: torch.Tensor, enclosing_type: str = "smallest"):
    """calculated 3d GIoU loss. assume the 3d bounding boxes are only rotated around z axis

    Args:
        box3d1 (torch.Tensor): (B, N, 3+3+1),  (x,y,z,w,h,l,alpha)
        box3d2 (torch.Tensor): (B, N, 3+3+1),  (x,y,z,w,h,l,alpha)
        enclosing_type (str, optional): type of enclosing box. Defaults to "smallest".

    Returns:
        (torch.Tensor): (B, N) 3d GIoU loss
        (torch.Tensor): (B, N) 3d IoU
    """
    iou3d, corners1, corners2, z_range, u3d = cal_iou_3d(box3d1, box3d2, verbose=True)
    w, h = enclosing_box(corners1, corners2, enclosing_type)
    v_c = z_range * w * h
    giou_loss = 1. - iou3d + (v_c - u3d) / v_c
    return giou_loss, iou3d


def cal_diou_3d(box3d1: torch.Tensor, box3d2: torch.Tensor, enclosing_type: str = "smallest"):
    """calculated 3d DIoU loss. assume the 3d bounding boxes are only rotated around z axis

    Args:
        box3d1 (torch.Tensor): (B, N, 3+3+1),  (x,y,z,w,h,l,alpha)
        box3d2 (torch.Tensor): (B, N, 3+3+1),  (x,y,z,w,h,l,alpha)
        enclosing_type (str, optional): type of enclosing box. Defaults to "smallest".

    Returns:
        (torch.Tensor): (B, N) 3d DIoU loss
        (torch.Tensor): (B, N) 3d IoU
    """
    iou3d, corners1, corners2, z_range, u3d = cal_iou_3d(box3d1, box3d2, verbose=True)
    w, h = enclosing_box(corners1, corners2, enclosing_type)
    x_offset = box3d1[..., 0] - box3d2[..., 0]
    y_offset = box3d1[..., 1] - box3d2[..., 1]
    z_offset = box3d1[..., 2] - box3d2[..., 2]
    d2 = x_offset * x_offset + y_offset * y_offset + z_offset * z_offset
    c2 = w * w + h * h + z_range * z_range
    diou = 1. - iou3d + d2 / c2
    return diou, iou3d


def enclosing_box(corners1: torch.Tensor, corners2: torch.Tensor, enclosing_type: str = "smallest"):
    if enclosing_type == "aligned":
        return enclosing_box_aligned(corners1, corners2)
    elif enclosing_type == "pca":
        return enclosing_box_pca(corners1, corners2)
    elif enclosing_type == "smallest":
        return smallest_bounding_box(torch.cat([corners1, corners2], dim=-2))
    else:
        ValueError("Unknow type enclosing. Supported: aligned, pca, smallest")


def enclosing_box_aligned(corners1: torch.Tensor, corners2: torch.Tensor):
    """calculate the smallest enclosing box (axis-aligned)

    Args:
        corners1 (torch.Tensor): (B, N, 4, 2)
        corners2 (torch.Tensor): (B, N, 4, 2)
    
    Returns:
        w (torch.Tensor): (B, N)
        h (torch.Tensor): (B, N)
    """
    x1_max = torch.max(corners1[..., 0], dim=2)[0]  # (B, N)
    x1_min = torch.min(corners1[..., 0], dim=2)[0]  # (B, N)
    y1_max = torch.max(corners1[..., 1], dim=2)[0]
    y1_min = torch.min(corners1[..., 1], dim=2)[0]

    x2_max = torch.max(corners2[..., 0], dim=2)[0]  # (B, N)
    x2_min = torch.min(corners2[..., 0], dim=2)[0]  # (B, N)
    y2_max = torch.max(corners2[..., 1], dim=2)[0]
    y2_min = torch.min(corners2[..., 1], dim=2)[0]

    x_max = torch.max(x1_max, x2_max)
    x_min = torch.min(x1_min, x2_min)
    y_max = torch.max(y1_max, y2_max)
    y_min = torch.min(y1_min, y2_min)

    w = x_max - x_min  # (B, N)
    h = y_max - y_min
    return w, h


def enclosing_box_pca(corners1: torch.Tensor, corners2: torch.Tensor):
    """calculate the rotated smallest enclosing box using PCA

    Args:
        corners1 (torch.Tensor): (B, N, 4, 2)
        corners2 (torch.Tensor): (B, N, 4, 2)
    
    Returns:
        w (torch.Tensor): (B, N)
        h (torch.Tensor): (B, N)
    """
    B = corners1.size()[0]
    c = torch.cat([corners1, corners2], dim=2)  # (B, N, 8, 2)
    c = c - torch.mean(c, dim=2, keepdim=True)  # normalization
    c = c.view([-1, 8, 2])  # (B*N, 8, 2)
    ct = c.transpose(1, 2)  # (B*N, 2, 8)
    ctc = torch.bmm(ct, c)  # (B*N, 2, 2)
    # NOTE: the build in symeig is slow!
    # _, v = ctc.symeig(eigenvectors=True)
    # v1 = v[:, 0, :].unsqueeze(1)                   
    # v2 = v[:, 1, :].unsqueeze(1)
    v1, v2 = eigenvector_22(ctc)
    v1 = v1.unsqueeze(1)  # (B*N, 1, 2), eigen val
    v2 = v2.unsqueeze(1)
    p1 = torch.sum(c * v1, dim=-1)  # (B*N, 8), first principle component
    p2 = torch.sum(c * v2, dim=-1)  # (B*N, 8), second principle component
    w = p1.max(dim=-1)[0] - p1.min(dim=-1)[0]  # (B*N, ),  width of rotated enclosing box
    h = p2.max(dim=-1)[0] - p2.min(dim=-1)[0]  # (B*N, ),  height of rotated enclosing box
    return w.view([B, -1]), h.view([B, -1])


def eigenvector_22(x: torch.Tensor):
    """return eigenvector of 2x2 symmetric matrix using closed form
    
    https://math.stackexchange.com/questions/8672/eigenvalues-and-eigenvectors-of-2-times-2-matrix
    
    The calculation is done by using double precision

    Args:
        x (torch.Tensor): (..., 2, 2), symmetric, semi-definite
    
    Return:
        v1 (torch.Tensor): (..., 2)
        v2 (torch.Tensor): (..., 2)
    """
    # NOTE: must use doule precision here! with float the back-prop is very unstable
    a = x[..., 0, 0].double()
    c = x[..., 0, 1].double()
    b = x[..., 1, 1].double()  # (..., )
    delta = torch.sqrt(a * a + 4 * c * c - 2 * a * b + b * b)
    v1 = (a - b - delta) / 2. / c
    v1 = torch.stack([v1, torch.ones_like(v1, dtype=torch.double, device=v1.device)], dim=-1)  # (..., 2)
    v2 = (a - b + delta) / 2. / c
    v2 = torch.stack([v2, torch.ones_like(v2, dtype=torch.double, device=v2.device)], dim=-1)  # (..., 2)
    n1 = torch.sum(v1 * v1, keepdim=True, dim=-1).sqrt()
    n2 = torch.sum(v2 * v2, keepdim=True, dim=-1).sqrt()
    v1 = v1 / n1
    v2 = v2 / n2
    return v1.float(), v2.float()


if __name__ == "__main__":
    box3d1 = np.array([0, 0, 0, 3, 3, 3, 0])
    box3d2 = np.array([1, 1, 1, 2, 2, 2, np.pi / 3])
    tensor1 = torch.FloatTensor(box3d1).unsqueeze(0).unsqueeze(0).cuda()
    tensor2 = torch.FloatTensor(box3d2).unsqueeze(0).unsqueeze(0).cuda()
    giou_loss, iou = cal_giou_3d(tensor1, tensor1)
    print(giou_loss)
    print(iou)
