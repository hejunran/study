# -*- coding:utf-8 -*-

from __future__ import absolute_import, division, print_function
import numpy as np
import math
import torch


def gaussian_label(label, num_class, u=0, sig=4.0):
    x = np.array(range(math.floor(-num_class / 2), math.ceil(num_class / 2), 1))
    y_sig = np.exp(-(x - u) ** 2 / (2 * sig ** 2))
    return np.concatenate([y_sig[math.ceil(num_class / 2) - label:],
                           y_sig[:math.ceil(num_class / 2) - label]], axis=0)
    # x = torch.Tensor(range(math.floor(-num_class / 2), math.ceil(num_class / 2), 1))
    # y_sig = torch.exp(-(x - u) ** 2 / (2 * sig ** 2))
    # return torch.cat([y_sig[math.ceil(num_class / 2) - label:],
    #                   y_sig[:math.ceil(num_class / 2) - label]], dim=0)


def get_all_smooth_label(num_label, raduius=4):
    all_smooth_label = []

    for i in range(num_label):
        all_smooth_label.append(gaussian_label(i, num_label, sig=raduius))

    return np.array(all_smooth_label)

    # return [gaussian_label(i, num_label, sig=raduius) for i in range(0, num_label)]


def angle_smooth_label(angle_label, angle_range=180, raduius=4, omega=1):
    """
    :param angle_label: [-90,0) or [-90, 0)
    :param angle_range: 90 or 180
    :return:
    """

    assert angle_range % omega == 0, 'wrong omega'

    angle_range /= omega
    angle_label /= omega

    angle_label = np.array(-np.round(angle_label), np.int32)
    all_smooth_label = get_all_smooth_label(int(angle_range), raduius)
    inx = angle_label == angle_range
    angle_label[inx] = angle_range - 1
    smooth_label = all_smooth_label[angle_label]
    return np.array(smooth_label, np.float32)

    # assert angle_range % omega == 0, 'wrong omega'
    #
    # angle_range /= omega
    # angle_label /= omega
    #
    # angle_label = torch.Tensor(-torch.round(angle_label)).to(torch.int32)
    # all_smooth_label = get_all_smooth_label(int(angle_range), raduius)
    # inx = angle_label == angle_range
    # angle_label[inx] = angle_range - 1
    #
    # ctc = tuple([angle_label[i].item() for i in range(0, angle_label.size()[0])])
    # smooth_label = all_smooth_label[ctc]
    #
    # return [all_smooth_label(i) for i in range(0, angle_label.size()[0])]


if __name__ == '__main__':
    import matplotlib.pyplot as plt

    angle_label = np.array([-179.9, -45.2, -0.3, -1.9])
    smooth_label = angle_smooth_label(angle_label)
    print(smooth_label)

    # # y_sig = triangle_label(30, 180, raduius=8)
    # y_sig = gaussian_label(30, 180, sig=0.1)
    # # y_sig = pulse_label(30, 180)
    # # y_sig = triangle_label(0, 90)
    # x = np.array(range(0, 180, 1))
    # plt.plot(x, y_sig, "r-", linewidth=2)
    # plt.grid(True)
    # plt.show()
    # print(y_sig)
