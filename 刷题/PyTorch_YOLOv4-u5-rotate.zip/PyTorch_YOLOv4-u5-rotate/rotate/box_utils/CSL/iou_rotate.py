# -*- coding: utf-8 -*-

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import time
# import tensorflow as tf
import sys
import torch
import math

sys.path.append('../..')
from rotate.box_utils.CSL.coordinate_convert import *
# from shapely.geometry import Polygon, MultiPoint

# from libs.box_utils.rbbox_overlaps import rbbx_overlaps
# from libs.box_utils.iou_cpu import get_iou_matrix

'''
 boxes_list1:[N, 8] tensor
 boxes_list2: [M, 8] tensor
'''
'''
def iou_rotate_calculate(boxes1, boxes2, use_gpu=True, gpu_id=0):

    boxes1 = tf.cast(boxes1, tf.float32)
    boxes2 = tf.cast(boxes2, tf.float32)
    if use_gpu:

        iou_matrix = tf.py_func(rbbx_overlaps,
                                inp=[boxes1, boxes2, gpu_id],
                                Tout=tf.float32)
    else:
        iou_matrix = tf.py_func(get_iou_matrix, inp=[boxes1, boxes2],
                                Tout=tf.float32)

    iou_matrix = tf.reshape(iou_matrix, [tf.shape(boxes1)[0], tf.shape(boxes2)[0]])

    return iou_matrix
'''


######################################
# TODO 新添加的数据预处理中计算旋转anchor的iou
######################################
def cp_iou_rotate_calculate1(boxes1, boxes2, use_gpu=False, gpu_id=0):
    # start = time.time()
    if use_gpu:
        ious = []
        # ious = rbbx_overlaps(boxes1, boxes2, gpu_id)
    else:
        area1 = boxes1[:, 2] * boxes1[:, 3]
        area2 = boxes2[:, 2] * boxes2[:, 3]
        ious = []
        for i, box1 in enumerate(boxes1):
            temp_ious = []
            r1 = ((box1[0], box1[1]), (box1[2], box1[3]), box1[4])
            for j, box2 in enumerate(boxes2):
                r2 = ((box2[0], box2[1]), (box2[2], box2[3]), box2[4])

                int_pts = cv2.rotatedRectangleIntersection(r1, r2)[1]
                if int_pts is not None:
                    order_pts = cv2.convexHull(int_pts, returnPoints=True)

                    int_area = cv2.contourArea(order_pts)

                    inter = int_area * 1.0 / (area1[i] + area2[j] - int_area)
                    temp_ious.append(inter)
                else:
                    temp_ious.append(0.0)
            ious.append(temp_ious)

    # print('{}s'.format(time.time() - start))

    return np.array(ious, dtype=np.float32)


def iou_rotate_calculate1(boxes1, boxes2):
    area1 = boxes1[:, 2] * boxes1[:, 3]
    area2 = boxes2[:, 2] * boxes2[:, 3]
    ious = []
    for i, box1 in enumerate(boxes1):
        temp_ious = []
        r1 = ((box1[0], box1[1]), (box1[2], box1[3]), box1[4])
        for j, box2 in enumerate(boxes2):
            r2 = ((box2[0], box2[1]), (box2[2], box2[3]), box2[4])
            int_pts = cv2.rotatedRectangleIntersection(r1, r2)[1]
            if int_pts is not None:
                order_pts = cv2.convexHull(int_pts, returnPoints=True)

                int_area = cv2.contourArea(order_pts)

                inter = int_area * 1.0 / (area1[i] + area2[j] - int_area)
                temp_ious.append(inter)
            else:
                temp_ious.append(0.0)
        ious.append(temp_ious)

    return np.array(ious, dtype=np.float32)


def iou_rotate_calculate2(boxes1, boxes2):
    ious = []
    if boxes1.shape[0] != 0:
        area1 = boxes1[:, 2] * boxes1[:, 3]
        area2 = boxes2[:, 2] * boxes2[:, 3]

        for i in range(boxes1.shape[0]):
            temp_ious = []
            r1 = ((boxes1[i][0], boxes1[i][1]), (boxes1[i][2], boxes1[i][3]), boxes1[i][4])
            r2 = ((boxes2[i][0], boxes2[i][1]), (boxes2[i][2], boxes2[i][3]), boxes2[i][4])

            int_pts = cv2.rotatedRectangleIntersection(r1, r2)[1]
            if int_pts is not None:
                order_pts = cv2.convexHull(int_pts, returnPoints=True)

                int_area = cv2.contourArea(order_pts)

                inter = int_area * 1.0 / (area1[i] + area2[i] - int_area)
                temp_ious.append(inter)
            else:
                temp_ious.append(0.0)
            ious.append(temp_ious)

    return torch.FloatTensor(np.array(ious, dtype=np.float32))

'''
def giou_rotate_calculate(boxes1, boxes2):
    if boxes1.shape[0] != 0:

        boxes1 = forward_convert(boxes1, with_label=False)
        boxes2 = forward_convert(boxes2, with_label=False)

        gious = []
        for i in range(boxes1.shape[0]):
            box1 = boxes1[i]
            box2 = boxes2[i]

            a = box1.reshape(4, 2)
            b = box2.reshape(4, 2)
            # 所有点的最小凸的表示形式，四边形对象，会自动计算四个点，最后顺序为：左上 左下  右下 右上 左上
            poly1 = Polygon(a).convex_hull
            poly2 = Polygon(b).convex_hull
            if not poly1.is_valid or not poly2.is_valid:
                print('formatting errors for boxes!!!! ')
                return 0
            if poly1.area == 0 or poly2.area == 0:
                return 0

            inter = Polygon(poly1).intersection(Polygon(poly2)).area

            iou = inter / (poly1.area + poly2.area - inter + 1e-16)

            union_poly = np.concatenate((a, b))
            union = MultiPoint(union_poly).envelope.area

            giou = iou - inter / (union + 1e-16)
            gious.append(giou)
    else:
        gious = []

    ######################################
    # TODO  是否能优化
    ######################################
    return np.reshape(np.array(gious, dtype=np.float32), [-1, 1])
'''

def diou_rotate_calculate(boxes1, boxes2):
    if boxes1.shape[0] != 0:
        area1 = boxes1[:, 2] * boxes1[:, 3]
        area2 = boxes2[:, 2] * boxes2[:, 3]

        boxes1_ = forward_convert(boxes1, with_label=False)
        boxes2_ = forward_convert(boxes2, with_label=False)

        xmin = np.minimum([np.min(boxes1_[i, 0::2]) for i in range(len(boxes1_))],
                          [np.min(boxes2_[i, 0::2]) for i in range(len(boxes2_))])
        xmax = np.maximum([np.max(boxes1_[i, 0::2]) for i in range(len(boxes1_))],
                          [np.max(boxes2_[i, 0::2]) for i in range(len(boxes2_))])
        ymin = np.minimum([np.min(boxes1_[i, 1::2]) for i in range(len(boxes1_))],
                          [np.min(boxes2_[i, 1::2]) for i in range(len(boxes2_))])
        ymax = np.maximum([np.max(boxes1_[i, 1::2]) for i in range(len(boxes1_))],
                          [np.max(boxes2_[i, 1::2]) for i in range(len(boxes2_))])

        dious = []
        for i in range(boxes1.shape[0]):
            boxes1_1 = boxes1[i]
            boxes2_1 = boxes2[i]

            d = (boxes1_1[0] - boxes2_1[0]) ** 2 + (boxes1_1[1] - boxes2_1[1]) ** 2

            c = (xmax[i] - xmin[i]) ** 2 + (ymax[i] - ymin[i]) ** 2

            r1 = ((boxes1[i][0], boxes1[i][1]), (boxes1[i][2], boxes1[i][3]), boxes1[i][4])
            r2 = ((boxes2[i][0], boxes2[i][1]), (boxes2[i][2], boxes2[i][3]), boxes2[i][4])

            int_pts = cv2.rotatedRectangleIntersection(r1, r2)[1]
            if int_pts is not None:
                order_pts = cv2.convexHull(int_pts, returnPoints=True)

                int_area = cv2.contourArea(order_pts)

                iou = int_area * 1.0 / (area1[i] + area2[i] - int_area)
            else:
                iou = 0.0

            diou = iou - d / c

            dious.append(diou)
    else:
        dious = []

    ######################################
    # TODO  是否能优化
    ######################################
    return np.reshape(np.array(dious, dtype=np.float32), [-1, 1])


def ciou_rotate_calculate(boxes1, boxes2):
    print(type(boxes1), type(boxes2))
    if boxes1.shape[0] != 0:
        area1 = boxes1[:, 2] * boxes1[:, 3]
        area2 = boxes2[:, 2] * boxes2[:, 3]

        boxes1_ = forward_convert(boxes1, with_label=False)
        boxes2_ = forward_convert(boxes2, with_label=False)

        xmin = np.minimum([np.min(boxes1_[i, 0::2]) for i in range(len(boxes1_))],
                          [np.min(boxes2_[i, 0::2]) for i in range(len(boxes2_))])
        xmax = np.maximum([np.max(boxes1_[i, 0::2]) for i in range(len(boxes1_))],
                          [np.max(boxes2_[i, 0::2]) for i in range(len(boxes2_))])
        ymin = np.minimum([np.min(boxes1_[i, 1::2]) for i in range(len(boxes1_))],
                          [np.min(boxes2_[i, 1::2]) for i in range(len(boxes2_))])
        ymax = np.maximum([np.max(boxes1_[i, 1::2]) for i in range(len(boxes1_))],
                          [np.max(boxes2_[i, 1::2]) for i in range(len(boxes2_))])

        cious = []
        for i in range(boxes1.shape[0]):
            boxes1_1 = boxes1[i]
            boxes2_1 = boxes2[i]

            r1 = ((boxes1[i][0], boxes1[i][1]), (boxes1[i][2], boxes1[i][3]), boxes1[i][4])
            r2 = ((boxes2[i][0], boxes2[i][1]), (boxes2[i][2], boxes2[i][3]), boxes2[i][4])

            d = (boxes1_1[0] - boxes2_1[0]) ** 2 + (boxes1_1[1] - boxes2_1[1]) ** 2

            c = (xmax[i] - xmin[i]) ** 2 + (ymax[i] - ymin[i]) ** 2

            v = (4 / (math.pi ** 2)) * torch.pow((
                    torch.atan(boxes1_1[2] / boxes1_1[3]) - torch.atan(boxes2_1[2] / boxes2_1[3])), 2)

            int_pts = cv2.rotatedRectangleIntersection(r1, r2)[1]
            if int_pts is not None:
                order_pts = cv2.convexHull(int_pts, returnPoints=True)

                int_area = cv2.contourArea(order_pts)

                iou = int_area * 1.0 / (area1[i] + area2[i] - int_area)
            else:
                iou = 0.0

            alpha = v / (1 - iou + v)

            ciou = iou - (d / c + alpha * v)

            cious.append(ciou)
    else:
        cious = []

    return torch.FloatTensor(np.reshape(np.array(cious, dtype=np.float32), [-1, 1]))


if __name__ == '__main__':
    anchors = [[142., 110., -30], [192., 243., -45], [459., 401., -60]]
    angle = -45
    num_anchors = 3
    gw, gh = 13, 13

    gt_box = torch.FloatTensor(np.array([0, 0, gw, gh, angle])).unsqueeze(0)
    print(gt_box)

    # 计算出所有先验框的位置
    anchor_shapes = torch.FloatTensor(np.concatenate((np.zeros((num_anchors, 2)),
                                                      np.array(anchors)), 1))
    print(anchor_shapes)
    print(iou_rotate_calculate1(gt_box, anchor_shapes))

    # # boxes1 = np.array([[0., 0., 13., 13., -45.]], np.float32)
    # boxes1 = torch.tensor([[0., 0., 13., 13., -45.]], requires_grad=True)
    #
    # # boxes2 = np.array([[0., 0., 142., 110., -30.]], np.float32)
    # boxes2 = torch.tensor([[0., 0., 142., 110., -30.]])
    #
    #
    # print(ciou_rotate_calculate(boxes1, boxes2))

    # print(1 - iou_rotate_calculate2(boxes1, boxes2))

    # start = time.time()
    # with tf.Session() as sess:
    #     ious = iou_rotate_calculate1(boxes1, boxes2, use_gpu=False)
    #     print(sess.run(ious))
    #     print('{}s'.format(time.time() - start))

    # start = time.time()
    # for _ in range(10):
    #     ious = rbbox_overlaps.rbbx_overlaps(boxes1, boxes2)
    # print('{}s'.format(time.time() - start))
    # print(ious)

    # print(ovr)
