# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, division
import numpy as np


####################################
#
#  base_anchor_size = [[[142., 110.], [192., 243.], [459., 401.]],
#                      [[36., 75.], [76., 55.], [72., 146.]],
#                      [[12., 16.], [19., 36.], [40., 28.]]]
#  anchor_angless = [-90, -75, -60, -45, -30, -15]
####################################
def make_anchors(base_anchor, anchor_angles, name='make_ratate_anchors'):
    """
    :param base_anchor:
    :param anchor_angles:
    :param name:
    :return:
    """
    base_anchor = base_anchor.tolist()
    anchor = []
    for stage_num in range(len(base_anchor)):
        for per_stage in range(len(base_anchor[stage_num])):
            for i, anchor_angle in enumerate(anchor_angles):
                per_stage_anchor = base_anchor[stage_num][:][per_stage].copy()
                per_stage_anchor.append(anchor_angle)
                anchor.append(per_stage_anchor)
    return np.array(anchor)


if __name__ == '__main__':
    # base_anchor = [[[142., 110.], [192., 243.], [459., 401.]], [[36., 75.], [76., 55.], [72., 146.]],
    #                [[12., 16.], [19., 36.], [40., 28.]]]

    # base_anchor = np.array([[[13, 17], [22, 25], [27, 66], [55, 41]],
    #                [[57, 88], [112, 69], [69, 177], [136, 138]],
    #                [[136, 138], [287, 114], [134, 275], [268, 248]],
    #                [[268, 248], [232, 504], [445, 416], [640, 640]],
    #                [[812, 393], [477, 808], [1070, 908], [1408, 1408]]])

    # base_anchor = np.array([[[6, 12], [15, 7], [9, 21]], [[32, 10], [11, 33], [18, 52]], [[60, 18], [29, 95], [121, 25]]])
    base_anchor = np.array([[[8, 10], [24, 9], [10, 25]], [[44, 15], [16, 48], [80, 23]], [[26, 89], [149, 29], [34, 151]]])
    anchor_angless = [-90, -75, -60, -45, -30, -15]

    print(make_anchors(base_anchor, anchor_angless).reshape((3, -1, 3)))

    # base_anchor = tf.constant([0, 0, base_anchor_size, base_anchor_size], tf.float32)
    # tmp1 = enum_ratios_and_thetas(base_anchor_size, anchor_angless)
    # anchors = make_anchors(base_anchor_size, anchor_angless)

    # img = tf.ones([600, 1000, 3])
    # img = tf.expand_dims(img, axis=0)
    #
    # img1 = draw_box_with_color(img, anchors, text=tf.shape(anchors)[1])
    #
    # with tf.Session() as sess:
    #     temp1, _img1 = sess.run([anchors, img1])
    #
    #     _img1 = _img1[0]
    #
    #     cv2.imwrite('rotate_anchors.jpg', _img1)
    #     cv2.waitKey(0)
    #
    #     print(temp1)
    #     print('debug')
